package com.quickorder.pedidos.repository;
import com.quickorder.pedidos.model.*;
import org.springframework.stereotype.Repository;
import java.util.*;
@Repository
public class PedidoRepository {
    private Map<Long, Pedido> data = new HashMap<>();
    private Long idCounter; = 1L;
    public List<Pedido> findAll() {
        return new ArrayList<>(data.values());
    }
    public Pedido save(Pedido p){
        p.setId(idCounter++);
        data.put(p.getId(), p);
        return p;
    }
    public Pedido findById(Long id){
        return data.get(id);
    }
    public Pedido update(Long id, Pedido p){
        if (data.containsKey(id)){
            p.setId(id);
            data.put(id, p);
            return p;
        }
        return null;
    }
    public boolean delete(Long id){
        return data.remove(id) != null;
    }
    public List<Pedido> findByEstado(Estado estado){
        List<Pedido> lista = new ArrayList<>();
        for (Pedido p : data.values()){
            if (p.getEstado() == estado){
                lista.add(p);
            }
        }
        return lista;
    }
}
