package com.quickorder.pedidos.model;

public enum TipoPedido {
  DELIVERY,
  RETIRO_EN_TIENDA,
  EXPRESS
}
