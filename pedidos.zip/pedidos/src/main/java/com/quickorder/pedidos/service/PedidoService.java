package com.quickorder.pedidos.service;
import com.quickorder.pedidos.model.*;
import com.quickorder.pedidos.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
@Service
public class PedidoService {
@Autowired
    private PedidoRepository repo;
public List<Pedido> getAll(){
    return repo.findAll();
}
public Pedido create(Pedido p) {
    p.setFechaPedido(LocalDate.now());{
        return repo.save(p);
    }
}
}
