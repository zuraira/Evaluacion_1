package com.quickorder.pedidos.controller;

public class PedidoController {
}
