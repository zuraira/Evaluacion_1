package com.quickorder.pedidos.model;

public enum Estado {
    PENDIENTE,
    EN_PREPARACION,
    EN_CAMINO,
    ENTREGADO,
    CANCELADO
}
//Enum para determinar el estado de cada pedido//