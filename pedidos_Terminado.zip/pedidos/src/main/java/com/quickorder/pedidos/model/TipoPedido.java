package com.quickorder.pedidos.model;

public enum TipoPedido {
  DELIVERY,
  RETIRO_EN_TIENDA,
  EXPRESS
}
//Enum para determinar que tipo de pedido es//