package com.quickorder.pedidos.service;
import com.quickorder.pedidos.model.*;
import com.quickorder.pedidos.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
@Service
public class PedidoService {

    @Autowired // Inyección de dependencias: conecta el service con el repository
    private PedidoRepository repo;

    // Obtener todos los pedidos almacenados en la base de datos
    public List<Pedido> getAll(){
        return repo.findAll();
    }

    // Crear un nuevo pedido, asignando la fecha actual automáticamente
    public Pedido create(Pedido p) {
        p.setFechaPedido(LocalDate.now()); // Fecha del pedido se establece al momento de la creación
        return repo.save(p);
    }

    // Buscar un pedido por su ID
    public Pedido getById(Long id) {
        return repo.findById(id);
    }

    // Actualizar un pedido existente manteniendo la fecha original
    public Pedido update(Long id, Pedido p){
        Pedido existente = repo.findById(id);
        if (existente != null) {
            p.setFechaPedido(existente.getFechaPedido()); // Se conserva la fecha original del pedido
            return repo.update(id, p);
        }
        return null; // Si no existe, retorna null
    }

    // Eliminar un pedido por su ID
    public boolean delete(Long id) {
        return repo.delete(id);
    }

    // Obtener todos los pedidos filtrados por estado
    public List<Pedido> getByEstado(Estado estado){
        return repo.findByEstado(estado);
    }
}
