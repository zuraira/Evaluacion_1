package com.quickorder.pedidos.controller;
import com.quickorder.pedidos.model.*;
import com.quickorder.pedidos.service.PedidoService;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;
import java.util.ResourceBundle;

@RestController
@RequestMapping("/pedidos")

public class PedidoController {
    @Autowired //para conectar al Controller con el service//

    private PedidoService service;
    @GetMapping
    public ResponseEntity<List<Pedido>> listar() {
        return ResponseEntity.ok(service.getAll());
    }
    @PostMapping
    public ResponseEntity<?> crear (@Valid @RequestBody Pedido p){
        return ResponseEntity.status(201).body(service.create(p));
    }
    @GetMapping("/{id}")
    public ResponseEntity<?> obtener (@PathVariable Long id){
        Pedido p = service.getById(id);

        if (p == null){
            return ResponseEntity.status(404).body("No encontrado");
        }
        return ResponseEntity.ok(p);
    }
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(@PathVariable Long id, @Valid @RequestBody Pedido p) {
        Pedido actualizado = service.update(id,p);
        if (actualizado == null) {
            return ResponseEntity.status(404).body("No encontrado");
        }
        return ResponseEntity.ok(actualizado);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        if(service.delete(id)){
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(404).body("No encontrado");
    }
    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<Pedido>> filtrarPorEstado(@PathVariable Estado estado){
        return ResponseEntity.ok(service.getByEstado(estado));
    }
}
